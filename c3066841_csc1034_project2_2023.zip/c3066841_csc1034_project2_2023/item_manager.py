from item import Item
import csv


class ItemManager:

    def __init__(self, items=None):
        self.__items = items if items else []

    def get_items(self):
        return self.__items

    def __str__(self):
        return f"ItemManager: {self.__items}"

    def __repr__(self):
        return f"ItemManager({self.__items})"

    def add_item(self, item):
        if item not in self.__items:
            self.__items.append(item)

    def remove_item(self, item):
        if item in self.__items:
            self.__items.remove(item)

    def edit_item(self, old_item, new_item):
        if old_item in self.__items:
            index = self.__items.index(old_item)
            self.__items[index] = new_item

    def search_by_category(self, category):
        return [item for item in self.__items
                if item.get_category() == category]

    def search_by_perishable(self, perishable):
        return [item for item in self.__items
                if item.get_perishable() == perishable]

    def search_by_sell_price(self, sell_price):
        return [item for item in self.__items
                if item.get_sell_price() == sell_price]

    def apply_discount_to_items(self, names, discount):
        if not (0 <= discount <= 50):  # Giving discount 0 and 50 percent if exceeds 50 percent will raise error
            raise ValueError("Discount must be between 0% and 50%")

        for item in self.__items:
            if item.get_name() in names:
                new_sell_price = item.get_sell_price() * (1 - discount / 100)
                item.set_sell_price(new_sell_price)

    def purchase_available_items(self, names, is_member):
        total_cost = 0
        for item in self.__items:
            if item.get_name() in names:
                total_cost += item.get_sell_price()
                new_stock = item.get_stock() - 1  # It will gradually reduce the stock by 1
                if new_stock < 0:  # To raise value error if the stock is less than zero
                    raise ValueError(f"Stock for {item.get_name} cannot be less than zero")
                item.set_stock(new_stock)

        if is_member:  # if member get 10 percent not member get 5 percent only total cost exceeds 50
            if total_cost >= 50.0:
                total_cost *= 0.9
            else:
                total_cost *= 0.95
        return total_cost

    def load_from_file(self, file_name):
        with open(file_name, 'r') as f:
            next(f)  # To skip header line

            for line in f:
                item_data = line.strip().split(",")
                item = Item(item_data[0], item_data[1], bool(item_data[2]), int(item_data[3]), float(item_data[4]))
                existing_names = {existing_item.get_name() for existing_item in self.__items}
                if item.get_name() not in existing_names:    # check and neglect the duplicate names
                    self.__items.append(item)
                else:
                    print(f"Item with name '{item.get_name()} already exists and won't be loaded")

    def save_to_file(self, file_name):
        with open(file_name, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["name", "category", "perishable", "stock", "sell_price"])  # write for header
            for item in self.__items:  # write items
                writer.writerow(item.to_list())

