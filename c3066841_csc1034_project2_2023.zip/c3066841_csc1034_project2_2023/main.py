from item import Item
from item_manager import ItemManager


def main():
    # some new items
    item1 = Item("Mango", "Fruit", True, 60, 40.50)
    item2 = Item("Strawberry", "Fruit", True, 50, 120.60)
    item3 = Item("Pringles", "Food", False, 22, 70.22)
    # For Error test case For name
    print("Trying to put the item name that is not string")
    try:
        item4 = Item(20, "Food", False, 22, 39.0)
    except:
        print("Item name must be string")
    # For category
    print("\nTrying to put item category that is not string")
    try:
        item5 = Item("Banana", 20, False, 22, 39.0)
    except:
        print("Item category must be string")
    # For Perishable
    print("\nTrying to put item perishable that is not boolean")
    try:
        item6 = Item("Banana", "Fruit", "Mouse", 22, 39.0)
    except:
        print("Item perishable must be boolean")
    # For stock
    print("\nTrying to put item stock that is not integer")
    try:
        item7 = Item("Banana", "Fruit", False, True, 39.0)
    except:
        print("Item stock must be integer")
    # For sell_price
    print("\nTrying to put item that is not float")
    try:
        item8 = Item("Banana", "Fruit", False, 22, 39)
    except:
        print("Item sell price must be float")

    item_manager = ItemManager([item1, item2, item3])
    print("\nItems in List:")
    for item in item_manager.get_items():
        print(item)
    # Testing for eq in item.py
    print(item1.__eq__(item2))
    # Testing for hash in item.py
    print(item1.__hash__())
    # Testing for str in item_manager.py
    print(item1.__str__())
    # Testing for repr in item_manager.py
    print(item1.__repr__())
    # new item
    new_item = Item("Pepsi", "Drinks", False, 58, 5.15)
    item_manager.add_item(new_item)
    print("\nAdding New Item To List:")
    for item in item_manager.get_items():
        print(item)
    # Error test for add same item again
    print("\nAdding the same items again")
    try:
        item_manager.add_item(item1)
    except:
        print("Same items cannot be added")
    # item2 is removed and only 3 item left
    item_manager.remove_item(item2)
    print("\nAfter removing Item:")
    for item in item_manager.get_items():
        print(item)
    # new item is edited with edit item
    edited_item = Item("H&M", "Clothing", False, 30, 500.0)
    item_manager.edit_item(new_item, edited_item)
    print("\nEditing New Item:")
    for item in item_manager.get_items():
        print(item)
    # search by category
    category1_items = item_manager.search_by_category("Clothing")
    print("\nItems in Category:")
    for item in category1_items:
        print(item)
    # search by perishable
    perishable_items = item_manager.search_by_perishable(False)
    print("\nPerishable Items:")
    for item in perishable_items:
        print(item)
    # search by sell price
    sell_price_items = item_manager.search_by_sell_price(70.22)
    print("\nItems with Sell Price >= 70.22:")
    for item in sell_price_items:
        print(item)
    # apply discount to item with percentage between 0 and 50 now I gave 20 percent
    item_manager.apply_discount_to_items(["Mango", "Strawberry", "Pringles"], 20)
    print("\nAfter applying discount:")
    for item in item_manager.get_items():
        print(item)
    # Error test applying discount to item more than 50 percent
    print("\nApplying Discount more than 50 percent")
    try:
        item_manager.apply_discount_to_items(["Pringles"], 70)
    except:
        print("Discount must be between 0 and 50 percent")
    # Stock reduced after buying
    print("\n Remaining Stock after purchased")
    item_manager.purchase_available_items(["Pringles"], is_member=False)
    print(item_manager.get_items())
    # Error test for stock if less than zero
    print("\nTesting item stock if they are less than zero")
    try:
        item8 = Item("Grape", "Fruit", True, 0, 22)
    except:
        print("Item stock must not be less than zero")
    # total cost if they are member or not and apply discount
    total_cost = item_manager.purchase_available_items(["Mango", "H&M"], is_member=True)
    print(f"\nTotal Cost after discount for member: {total_cost}")
    # if they are not member but total cost is more than 50
    total_cost = item_manager.purchase_available_items(["Pringles"], is_member=False)
    print(f"\nTotal Cost after discount : {total_cost}")
    # load items from sample data
    item_manager.load_from_file("sample_data.csv")
    print("\nItems loaded from file:")
    print(item_manager.get_items())
    # save the new items to save data csv with old items but item2 will not save data because it is removed
    item_manager.save_to_file("sample_data.csv")
    print(item_manager.get_items())


main()
