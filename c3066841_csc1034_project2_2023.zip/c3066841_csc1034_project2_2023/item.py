class Item:

    def __init__(self, name, category, perishable, stock, sell_price):
        self.total_cost = None
        if not isinstance(name, str):  # A method to get name,category,perishable,stock and sell price
            raise TypeError("Item name should be string")  # Except stock and sell price have to be greater than zero
        if not isinstance(category, str):
            raise TypeError("Item category should be string")
        if not isinstance(perishable, bool):
            raise TypeError("Item perishable should be boolean")
        if not isinstance(stock, int):
            raise TypeError("Item stock should be integer")
        elif stock < 0:
            raise ValueError("Item stock must be greater or equal zero")
        if not isinstance(sell_price, float):
            raise TypeError("Item sell price must be float")
        elif sell_price <= 0:
            raise ValueError("Item sell price must be grater or equal zero")
        self.__name = name
        self.__category = category
        self.__perishable = perishable
        self.__stock = stock
        self.__sell_price = sell_price

    def get_name(self):
        return self.__name

    def get_category(self):
        return self.__category

    def get_perishable(self):
        return self.__perishable

    def get_stock(self):
        return self.__stock

    def set_stock(self, new_stock):  # a method to reduce stock after selling
        self.__stock = new_stock

    def get_sell_price(self):
        return self.__sell_price

    def set_sell_price(self, new_sell_price):  # a method for new sell price after discount
        self.__sell_price = new_sell_price

    def to_list(self):
        return [self.__name, self.__category, self.__perishable, self.__stock, self.__sell_price]

    def __str__(self):
        return f"Item({self.__name}, {self.__category}, {self.__perishable}, {self.__stock}, {self.__sell_price})"

    def __repr__(self):
        return f"Item('{self.__name}', '{self.__category}', {self.__perishable}, {self.__stock}, {self.__sell_price})"

    def __eq__(self, other):  # To make other item is equal to original item from name to sell price
        if not isinstance(other, Item):
            return False
        else:
            return (
                    self.__name == other.__name
                    and self.__category == other.__category
                    and self.__perishable == other.__perishable
                    and self.__stock == other.__stock
                    and self.__sell_price == other.__sell_price
            )

    def __hash__(self):
        return hash(
            (
                self.__name,
                self.__category,
                self.__perishable,
                self.__stock,
                self.__sell_price
            )
        )

